libgluon_drm.so is (c) 2021, Gluon, All Rights Reserved

If you want to enable the Gluon Commercial Extensions, which include
libgluon_drm.so, you should set the environment variable

ENABLE_GLUON_COMMERCIAL_EXTENSIONS

e.g. by typing

export ENABLE_GLUON_COMMERCIAL_EXTENSIONS=true

You are allowed to do this in either of the following cases:
1. Your application is non-commercial
2. You obtained a valid license from Gluon.
   Contact Gluon via https://gluonhq.com/contact-embedded

Unless expressly stated otherwise, Gluon Software makes no warranties
about the Software and cannot guarantee the accuracy of this Rights Statement.
You are responsible for your own use.
You may find additional information about the copyright status of the Software
on Gluon Software's web site.
You may need to obtain other permissions for your intended use. For example,
other rights such as publicity, privacy or moral rights may limit how you may
use the material.
